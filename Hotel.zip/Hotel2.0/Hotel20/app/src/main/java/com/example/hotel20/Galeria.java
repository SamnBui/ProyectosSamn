package com.example.hotel20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Galeria extends AppCompatActivity implements View.OnClickListener {

  public   ImageView foto1, foto2, foto4, foto5, foto6, foto7, foto8, foto9, foto10, foto11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_galeria);

        foto1 = (ImageView) findViewById(R.id.foto1);
        foto2 = (ImageView) findViewById(R.id.foto2);
        foto4 = (ImageView) findViewById(R.id.foto4);
        foto5 = (ImageView) findViewById(R.id.foto5);
        foto6 = (ImageView) findViewById(R.id.foto6);
        foto7 = (ImageView) findViewById(R.id.foto7);
        foto8 = (ImageView) findViewById(R.id.foto8);
        foto9 = (ImageView) findViewById(R.id.foto9);
        foto10 = (ImageView) findViewById(R.id.foto10);
        foto11 = (ImageView) findViewById(R.id.foto11);

        foto1.setOnClickListener(this);
        foto2.setOnClickListener(this);
        foto4.setOnClickListener(this);
        foto5.setOnClickListener(this);
        foto6.setOnClickListener(this);
        foto7.setOnClickListener(this);
        foto8.setOnClickListener(this);
        foto9.setOnClickListener(this);
        foto10.setOnClickListener(this);
        foto11.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        //enviamos parametros para la actividad
        startActivity(new Intent(getApplicationContext(), Foto.class).putExtra("foto", view.getId()));
    }
}