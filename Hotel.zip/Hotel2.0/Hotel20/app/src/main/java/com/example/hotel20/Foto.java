package com.example.hotel20;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

public class Foto extends AppCompatActivity {

    public ImageView _foto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foto);

        _foto = (ImageView) findViewById(R.id.foto);

        //recibimos el intent de galeria
        String foto = getIntent().getExtras().getString("foto");
        //no nos recibe el parametro de la foto
        _foto.setImageResource(getResources().getIdentifier(foto, "drawable", getPackageName()));
    }
}