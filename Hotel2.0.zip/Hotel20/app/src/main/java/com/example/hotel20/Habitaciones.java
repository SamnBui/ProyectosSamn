package com.example.hotel20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.view.View;
import android.widget.Button;

public class Habitaciones extends AppCompatActivity implements View.OnClickListener {

    Button btnSimple, btnDoble, btnMatrimonial, btnFamiliar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habitaciones);

       btnSimple = (Button) findViewById(R.id.btnSimple);
       btnDoble = (Button) findViewById(R.id.btnDoble);
       btnMatrimonial = (Button) findViewById(R.id.btnMatrimonial);
       btnFamiliar = (Button) findViewById(R.id.btnFamiliar);

       btnSimple.setOnClickListener(this);
       btnDoble.setOnClickListener(this);
       btnMatrimonial.setOnClickListener(this);
       btnFamiliar.setOnClickListener(this);



    }

    @Override
    public void onClick(View view) {

        String WhatsApp = "3106010820";

        switch (view.getId()){
            case R.id.btnSimple:
                WhatsApp(WhatsApp);
            break;
            case R.id.btnDoble:
                WhatsApp(WhatsApp);
                break;
            case R.id.btnMatrimonial:
                WhatsApp(WhatsApp);
                break;
            case R.id.btnFamiliar:
                WhatsApp(WhatsApp);
                break;
        }

    }

    public void WhatsApp(String telefono){
        String ParaNumero = "57"+telefono;
        Intent sendIntent = new Intent("android.intent.action.MAIN");
        sendIntent.setComponent(new ComponentName("com.whatsapp","com.whatsapp.Conversation"));
        sendIntent.putExtra("jid", PhoneNumberUtils.stripSeparators(ParaNumero)+"@s.whatsapp.net");
        startActivity(sendIntent);
    }
}