package com.example.hotel20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

//Implementamos el onclicklistener para hacer un  llamado general a los botones
public class Menu extends AppCompatActivity implements View.OnClickListener {

    Button btnHabitaciones, btnNosotros, btnUbicacion, btnGaleria, btnReservas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btnHabitaciones = (Button) findViewById(R.id.btnHabitaciones);
        btnNosotros = (Button) findViewById(R.id.btnNosotros);
        btnUbicacion = (Button) findViewById(R.id.btnUbicacion);
        btnGaleria = (Button) findViewById(R.id.btnGaleria);
        btnReservas = (Button) findViewById(R.id.btnReservas);

        //Para cuando haga click llame a la activity
        btnHabitaciones.setOnClickListener(this);
        btnNosotros.setOnClickListener(this);
        btnUbicacion.setOnClickListener(this);
        btnGaleria.setOnClickListener(this);
        btnReservas.setOnClickListener(this);
    }

        //METODO GENERAL PARA ABRIR CADA ACTIVITY DE MANERA SENCILLA
    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.btnHabitaciones:
                startActivity(new Intent(getApplicationContext(), Habitaciones.class));
                break;
            case R.id.btnNosotros:
                startActivity(new Intent(getApplicationContext(), Nosotros.class));
                break;
            case R.id.btnGaleria:
                startActivity(new Intent(getApplicationContext(), Galeria.class));
                break;
            case R.id.btnReservas:
                Reservas();
                break;
            case R.id.btnUbicacion:
                Ubicacion();
                break;
        }

    }

    public void Ubicacion(){

        double latitud = 6.276135934276756;
        double longitud = -75.58660365946628 ;

        String nombre = "Compañia M&Y";

        String uriInicial = "geo:" + latitud +"," + longitud;
        String consulta = latitud + ","+ longitud + "("+nombre+")";
        String codigoConsulta = Uri.encode(consulta);

        String uriString = uriInicial + "?q=" + codigoConsulta + "&z=16";
        Uri uri = Uri.parse(uriString);
        Intent i = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(i);
    }

    public void Reservas(){

            String ParaNumero = "573106010820";

            try {
                Intent i = new Intent("android.intent.action.MAIN");
                i.setComponent(new ComponentName("com.whatsapp","com.whatsapp.Conversation"));


                i.putExtra(getIntent().EXTRA_TEXT, " ");
                i.putExtra("jid", PhoneNumberUtils.stripSeparators(ParaNumero)+"@s.whatsapp.net");
                startActivity(i);
            }
            catch (Exception e){
                Toast.makeText(this, "Error al comunicarnos con whatsApp", Toast.LENGTH_LONG).show();
            }

    }
}